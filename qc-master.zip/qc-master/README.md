# Quantum Teleportation in Python

This is a very small library that demonstrates some basic quantum computing including teleportion. I wrote this before realizing that sympy actually has some facilities for quantum computing. Oh, well... maybe my bare bones demo will help you visual QC a bit better.

Check out qc.py where I walk through creating qubits, operators, and the teleportation mechanics.  


